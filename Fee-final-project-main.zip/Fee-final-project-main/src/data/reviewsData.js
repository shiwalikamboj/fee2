const reviewsData = [
    {
        id: 1,
        name: "Atharva Kumar",
        date: "4 Aug 2022",
        review: "Sound is awesome and as I expected, love it.",
        rateCount: 5,
    },
    {
        id: 2,
        name: "Ritika Sen",
        date: "15 July 2022",
        review: "Very good and awesome product",
        rateCount: 5,
    },
    {
        id: 3,
        name: "Bhavesh Joshi",
        date: "10 June 2022",
        review: "Super amazing product !!!",
        rateCount: 4,
    },
    {
        id: 4,
        name: "Anandi Gupta",
        date: "6 May 2022",
        review: "Great NC, sound is a bit flat",
        rateCount: 4,
    },
    {
        id: 5,
        name: "Arif Khan",
        date: "27 April 2022",
        review: "Very good but still has flaws!",
        rateCount: 3,
    },
]

export default reviewsData;